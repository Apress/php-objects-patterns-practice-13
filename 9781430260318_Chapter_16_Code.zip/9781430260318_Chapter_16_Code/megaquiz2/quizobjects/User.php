<?php
/**
 * @package quizobjects
 */

class User {}
?>
