<?php
/**
 * @license   http://www.example.com Borsetshire Open License
 * @package  quizobjects 
 */

namespace megaquiz\quizobjects;

/**
 * @package  quizobjects 
 */
class User {}
?>
