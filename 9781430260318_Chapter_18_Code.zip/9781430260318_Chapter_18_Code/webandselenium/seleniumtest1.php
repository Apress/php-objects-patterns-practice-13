<?php
require_once('PHPUnit/Framework/TestCase.php');
require_once( "php-webdriver/lib/__init__.php" );


class seleniumtest extends PHPUnit_Framework_TestCase {
   protected function setUp() {
   }

   public function testAddVenue() {
   }
}
?>
