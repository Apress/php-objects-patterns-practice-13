<?php
require_once "PHPUnit/Framework/TestCase.php";

abstract class test_testutil_BaseTest extends PHPUnit_Framework_TestCase {
     
}
