<?php
// Task.php
namespace tasks;

class Task {
    function doSpeak() {
        print "hello\n";
    }
}
?>
