<?php
// useful/Outputter3.php
namespace useful;

class Outputter {
    // 
}
?>
