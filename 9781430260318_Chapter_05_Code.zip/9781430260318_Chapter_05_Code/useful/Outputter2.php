<?php
// useful/Outputter2.php
class useful_Outputter {
    // 
}
?>
