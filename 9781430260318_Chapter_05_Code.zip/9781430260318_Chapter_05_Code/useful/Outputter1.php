<?php
class Outputter {
    // output data
}
?>
