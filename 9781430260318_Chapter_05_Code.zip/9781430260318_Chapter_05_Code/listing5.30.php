<?php
require_once "fullshop.php";
$cd = new CdProduct("cd1", "bob", "bobbleson", 4, 50 );
var_dump( $cd );
?>
