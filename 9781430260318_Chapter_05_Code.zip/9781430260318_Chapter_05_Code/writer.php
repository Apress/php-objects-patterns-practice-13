<?php

class Writer {

}

?>
