<?php
class business_ShopProduct {
    function __construct() {
        print "business_ShopProduct constructor\n";
    }
}
?>
