<?php
namespace business;

class ShopProduct2 {
    function __construct() {
        print "business\ShopProduct2 constructor\n";
    }
}
?>
