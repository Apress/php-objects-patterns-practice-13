<?php
namespace business;

class ShopProduct3 {
    function __construct() {
        print "business\ShopProduct3 constructor\n";
    }
}
?>
