<?php
require_once "useful/Outputter1.php";
class Outputter {
    // output data
}
?>
