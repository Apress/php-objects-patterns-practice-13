<?php
// no namespace

class Lister {
    public static function helloWorld() {
        print "hello from global\n";
    }
}
?>
