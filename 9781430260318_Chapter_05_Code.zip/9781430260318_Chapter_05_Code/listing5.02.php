<?php
require_once "useful/Outputter2.php";
class my_Outputter {
    // output data
}
?>
