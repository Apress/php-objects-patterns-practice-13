<?php

spl_autoload_register();
$writer = new util\Writer();
?>
