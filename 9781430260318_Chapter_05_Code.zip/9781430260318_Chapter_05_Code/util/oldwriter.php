<?php

class util_Writer {

}

?>
