<?php
namespace util;

class Writer {

}

?>
