<?php
namespace my;
require_once "useful/Outputter3.php";

class Outputter {
    // output data
}
?>
