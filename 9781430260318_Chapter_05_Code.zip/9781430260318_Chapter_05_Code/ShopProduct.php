<?php

class ShopProduct {
    function __construct() {
        print "ShopProduct constructor\n";
    }
}
?>
