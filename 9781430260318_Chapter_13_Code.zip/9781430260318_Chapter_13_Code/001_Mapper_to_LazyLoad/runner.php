<?php
require_once( "woo/controller/Controller.php");
//require_once( "woo/base/ApplicationRegistry.php");
\woo\controller\Controller::run();
?>
