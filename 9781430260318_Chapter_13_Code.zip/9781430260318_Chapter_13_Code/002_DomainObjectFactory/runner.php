<?php
require_once( "woo/controller/Controller.php"); // using the real one now
\woo\controller\Controller::run();
?>
