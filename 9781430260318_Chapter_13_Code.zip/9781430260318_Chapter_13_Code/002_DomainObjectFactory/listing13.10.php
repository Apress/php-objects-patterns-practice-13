<?php

// see woo/mapper/DomainObjectFactory.php

?>
